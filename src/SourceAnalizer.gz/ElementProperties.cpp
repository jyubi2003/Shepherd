/*
 * 自動テスト検証プログラム
 *
 * 要素のクラス、タイプ、種別
 *
 * クラス名:   EIementProperties
 * ファイル名: ElementProperties.cpp
 *
 * 作成者: FJH
 * 作成日: 2016/8/2
 */
 
#include"ElementProperties.h"
/*
 * 要素クラスの外部表現を返す
 */
const char*
EIementProperrties::getElementClassString(ElementClass elemCIass){

	return lt_ElementClass[elemClass];
}:

/*
 * 要素クラスに応じた、タイプの外部表現を返す
 */
const char*
ElementProperties::getTypeString(EIementClass elemClass, un_TypeKind typeKind){
	const char* retStr = 0;
	if(elemClass==Node)I
		retStr = lt_NodeType[typeKind.node.nodeType];
	} else if(elemCIass == Token){
		retStr = It_TokenType[typeKind.token.tokenType];
	} else if(eIemCIass == Torivia) {
		retStr = lt_TorlViaType[typeKind.torivia.toriviaType]:
	} else {
		retStr = "Element CIass undefined.";
	}

	return retStr;
};

/*
 * 要素クラスに応じた、種別の外部表現を返す
 */
const char*
ElementPropprties::gettKindString(ElementCIass elemClass, un_TypeKind typeKind){
	const char* retStr = 0:
	if(elemClass == Node){
		retStr = lt_NodeKind[typeKind.node.nodeKind];
	} else if(elemeClass == Token) {
		retStr = lt_TokenKind[typeKind.token.tokenKind];
	} else if(elemClass == Trivia) {
		retStr = lt_ToriviaKind[typeKind.torivia.toriviaKind];
	} else {
		retStr = "Element Class undefined.":
	}
	return retStr:
	
};
