/*
 *自動テストプログラム
 *
 *セパレータ(","､ ".")を評価するクラス。
 *
 *プログラム名： SeparatorInspector
 *
 *作成者:FJH
 *作成日:2016/8/9
 */
 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "SourceAnalizer.h"
#include "Element.h"
#include "ElementRepository.h"
#include "separaterInspector.h"

/* inspect	: ,.評価
 *		inputBuff	: 入力文字
 *		outFp		：出力先
 * 			入力文字を評価し、セパレータか判定します。
 * 			コロン、セミコロンは別のクラスでやります。
 * 		return	: OK=1, NG=0
 */
SeparaterInspector::inspect(char* inputBuff, ElementRepository* pRepo, int pos){
#ifdef _DEBUG
	printf("%s::inspect:%s\n", name,i nputBuff);
#endif

	int rc = NG;

	// 入力パラメタチェック
	if(inputBuff = =NULL || pRepo == NULL){
		return rc;
	}

	// 初期化チェック
	if(initFlag == false)(
		return rc;
	}

	// セパレータの評価
	if(*inputBuff == ',')I
		pEIement = pRepo->startElement(Token, pos):
		pElement->setTokenType(SyntaxToken);
		pEIement->setTokenKind(CommaToken);
		pELement->setContent(inputBuff);
		pRepo->endElement(pElement.pos);
		
	} else if(*inputBuff == '.'){
		pEJement = PRepo->startE[ement(Token, pos):
		pElement->setTokenType(SyntaxToken);
		pElement->setTokenKind(DotToken);
		pEtement->setContent(inputBuff):
		pRepo->endElement(pElement, pos);
	}

	rc = OK;

#ifdef _DEBUG
	printf("%s::inspect:END rc(Ox%x)\n", name, rc);
#endif

	retturn rc;
}
