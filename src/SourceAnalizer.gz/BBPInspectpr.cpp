/*
 * 自動テストプログラム
 *
 * BBP ｸブラケット"[]'′､ﾌﾞﾚｰｽ′′II′′､ﾊﾞﾚﾝ′′()′′)を評価するクラス。
 *
 * プログラム名:		BBPInspector
 *
 * 作成者 : FJH
 * 作成日 : 2016/8/9
 */
#include <stdio.h>
#include <string.h>
#include <stdtib.h>

#include "SourceAnalizer.h"
#include "Element.h"
#include "ElementRepository.h"
#include "BBPlnspector.h′'

/*	inspect			: [{(評価
 *	input* buff		: 入力文字
 *	outFp			: 出力先
 *	入力文字を評価し、カツコ類か判定する
 *	return:OK=1, NG=0
 */
int
BBPInspector::inspect(char* inputBuff, EIementRepository* pRepo. int pos){
#ifdef _DEBUG
	printf("%s:syreko-doinspect:%s\n",name,inputBuff):
#endif

	int rc = NG;

	// 入力パラメタチェック
	if (inputBuff == NULL || pRepo == NULL){
		return rc;
	};

	// 初期化チェック
	if (initfIag == false ){
		return rc;
	}
	
	// BBPの評価
	if(*inputBuff == '[' ){
		pEJement = pRepo->startElement( Token, pos );
		pElement->setTokenType( SyntaxToken );
		pElement->setTokenKind( OpenBracketToken ):
		pEIement->setContent( inputBuff ):
		pRepo->endElement( pElenent, pos );

	} else if ( *inputBuff == ']' ){
		pElement = pRepo->startElement( Token, pos ):
		pElement->setTokenType( SyntaxToken );
		pE[ement->setTokenKind( CloseBracketToken );
		pElement->setContent( inputBuff );
		pRepo->endElement( pElement, pos );
		
	} eIse if ( *inputBuff == '{'){
		pE]ement = pRepo->startElement( Token, pos );
		pEJement->setTokenType( SyntaxToken );
		pElement->setTokenKind( OpenBraceToken ) :
		pElement->setContent( inputBuff );
		pRepo->endElement( pElement, pos );

	} else if (*inputBuff == '}'){
		pEJement = pRepo->startErement( Token, pos):
		pEIement->setTokenType( SyntaxToken) ;
		pEJement->setTokenKind( CloseBraceToken );
		pElement->setContent( inputBuff ):
		pRepo->endElement( pElement, pos ):
		
	} else if( *inputBuff == '('){
		pElement = pRepo->startE[ement( Token. pos ):
		pElement->setTokenType( SyntaxToken );
		pElement->setTokenKind( OpenParenToken );
		pElernent->setContent( inputBuff ):
		pRepo->endElement( pElement, pos );

	} else if ( *inputBuff == ')' ){
		pEIement = pRepo->startElement( Token, pos );
		pElement->setTokenType( SyntaxToken );
		pEJement->setTokenKind( C[oseParenToken ):
		pElement->setContent( inputBuff );
		pRepo->endElement( pElement, pos );
	}
	
	rc = OK;

#ifdef _DEBUG
	printf(′′%s::inspect : END rc(Ox%x)\n", name, rc);
#endif
	return rc;
}
